# PocketSmart AI

PocketSmart AI is a FastAPI + Jinja2 + Gemini-powered budget and recommendation assistant based on the supplied project documentation.

## Included planners

- Home Interior Planner
- Party Budget Planner
- Jewelry Budget Planner with optional outfit image
- Registration/login
- Dashboard
- Recommendation history
- JSON API endpoints
- SQLite persistence
- Gemini AI integration with a deterministic fallback when no API key is configured

## Architecture

```text
Browser
  |
  +-- Jinja2 pages / static CSS + JS
  |
FastAPI
  |
  +-- auth.py -------- password hashing + signed session cookie
  +-- routes/api.py -- planner API + history
  +-- services/
  |      +-- gemini_service.py
  |      +-- recommender.py
  |
  +-- SQLAlchemy ---- SQLite
  |
Gemini API (optional)
```

The original document mentions Flask early and FastAPI in later milestones. This implementation uses FastAPI because the document's later backend architecture, endpoints, authentication, and UI sections consistently specify FastAPI.

## 1. Requirements

- Windows 10/11, macOS, or Linux
- Python 3.11+
- VS Code
- Optional: Gemini API key

## 2. VS Code setup

Open the project folder in VS Code.

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

If PowerShell blocks activation, use Command Prompt:

```cmd
.venv\Scripts\activate
```

Then edit `.env` and set:

```env
GEMINI_API_KEY=your_key_here
```

Do not commit `.env`.

## 3. Run

```powershell
python -m uvicorn app.main:app --reload
```

Open:

- http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs

## 4. Run without Gemini

You can leave `GEMINI_API_KEY` empty. The app still runs and uses built-in deterministic recommendations. This makes it easy to test the UI and database before connecting AI.

## 5. Test

```powershell
python -m pytest -q
```

## 6. API endpoints

### Authentication

- `POST /api/register`
- `POST /api/login`
- `POST /api/logout`
- `GET /api/session-info`
- `GET /api/session-data`

### Planners

- `POST /api/generate-home`
- `POST /api/generate-party`
- `POST /api/generate-jewelry`

### History

- `GET /api/history`
- `GET /api/history/{id}`
- `DELETE /api/history/{id}`

### Health

- `GET /api/health`

## 7. Gemini model

The model is controlled by:

```env
GEMINI_MODEL=gemini-2.5-flash
```

Change it to a currently available Gemini model in your account if needed. The application does not depend on a model-specific name in its code.

## 8. Product/service links

The supplied document asks for Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO-style sources. This project intentionally creates search links rather than pretending to have private/live retailer APIs. AI-generated prices are labelled as estimates unless a real catalog integration is added.

## 9. Production notes

Before deployment:

- Use PostgreSQL instead of SQLite.
- Set a strong random `SECRET_KEY`.
- Put the app behind HTTPS.
- Set secure cookie flags in production.
- Add rate limiting.
- Add real retailer/vendor APIs only where you have legitimate API access.
- Never expose the Gemini API key to browser JavaScript.
